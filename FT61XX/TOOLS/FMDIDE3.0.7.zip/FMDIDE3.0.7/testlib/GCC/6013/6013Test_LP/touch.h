/**
  *********************************************************************************
  * @file    	    touch.h
  * @author  	    FMD AE
  * @brief   	    ��ͷ�ļ�
  * @version 	    V2.0.0           
  * @data		    2022-01-20
  *********************************************************************************
  * @attention
  * COPYRIGHT (C) 2021 Fremont Micro Devices Corporation All rights reserved.
  *    This software is provided by the copyright holders and contributors,and the
  *software is believed to be accurate and reliable. However, Fremont Micro Devices
  *Corporation assumes no responsibility for the consequences of use of such
  *software or for any infringement of patents of other rights of third parties,
  *which may result from its use. No license is granted by implication or otherwise
  *under any patent rights of Fremont Micro Devices Corporation.
  **********************************************************************************
  */  

  /**********************************************************************************
  * @оƬ��Դ
  **********************************************************************************
  */
 
#ifndef _TOUCH_H
#define _TOUCH_H

///////////ͷ�ļ�/////////////////////////////////////
#include <string.h>
#include "SYSCFG.h"

//���ͨѶҪ��������IO�ڣ�ע��POWER_INITIAL���������Ӧ��ͨѶIOҪ������
#define  TX  			RA7     
#define  TX_IO    		0x80
#define  TX_IO_ADDR   	TRISA   

/////////////����ϵͳʱ��///////////////////////////////////////////
#define SYS_OSCCON   0B01110001

/////////������ӦоƬKEYIOӳ�䶨��//////////////////////////
#define   KEY0_INDEX_MAP       7
#define   KEY1_INDEX_MAP       6
#define   KEY2_INDEX_MAP       5
#define   KEY3_INDEX_MAP       4
#define   KEY4_INDEX_MAP       2
#define   KEY5_INDEX_MAP       3
#define   KEY6_INDEX_MAP       0
#define   KEY7_INDEX_MAP       1
#define   KEY_NUMBER   8  //Ŀǰ���8��
const unsigned char ucKeyNumberMax = KEY_NUMBER;
const unsigned char ucKeyIndexMapArray[KEY_NUMBER]=
{
    KEY0_INDEX_MAP,
    KEY1_INDEX_MAP,
    KEY2_INDEX_MAP,
    KEY3_INDEX_MAP,
    KEY4_INDEX_MAP,
    KEY5_INDEX_MAP,
    KEY6_INDEX_MAP,
    KEY7_INDEX_MAP
};

//////////////io setting,�˴������޸�////////////////////////////////
#define SLEEP_SCAN_KEY_GROUP       4  	// ȡֵ��Χ 1~4
const unsigned char ucSleepGroupMax = SLEEP_SCAN_KEY_GROUP;
unsigned int uiSleepGroupBuffer[SLEEP_SCAN_KEY_GROUP];

#define 	TouchIoMaskB 	 0x03
#define 	TouchIoMaskC 	 0xFC
const unsigned char ucTouchIoMaskB = TouchIoMaskB;	
const unsigned char ucTouchIoMaskC = TouchIoMaskC;

#define   	SleepTrisB_0	 0x00
#define   	SleepTrisC_0     0x03
#define   	SleepTK_0        0x03
#define   	SleepTrisB_1	 0xC0
#define   	SleepTrisC_1     0x00
#define   	SleepTK_1        0x0C
#define   	SleepTrisB_2	 0x30
#define   	SleepTrisC_2     0x00
#define  	SleepTK_2        0x30
#define   	SleepTrisB_3	 0x0C
#define   	SleepTrisC_3     0x00
#define   	SleepTK_3        0xC0
const unsigned char ucSleepTrisB_0 = SleepTrisB_0;	
const unsigned char ucSleepTrisC_0 = SleepTrisC_0;
const unsigned char ucSleepTK_0 = SleepTK_0;
const unsigned char ucSleepTrisB_1 = SleepTrisB_1;	
const unsigned char ucSleepTrisC_1 = SleepTrisC_1;
const unsigned char ucSleepTK_1 = SleepTK_1;
const unsigned char ucSleepTrisB_2 = SleepTrisB_2;	
const unsigned char ucSleepTrisC_2 = SleepTrisC_2;
const unsigned char ucSleepTK_2 = SleepTK_2;
const unsigned char ucSleepTrisB_3 = SleepTrisB_3;	
const unsigned char ucSleepTrisC_3 = SleepTrisC_3;
const unsigned char ucSleepTK_3 = SleepTK_3;

///////////���ܺ�������/////////////////////////////////////

void TOUCH_INITIAL(void);  //�����������ó�ʼ��          
unsigned char TSC_SleepPrcoessing(void);//�͹����µĻ��Ѵ���
unsigned int Read_SpecialRam(unsigned char KeyIdx);//��ȡ���Ӧ����������    

#endif
