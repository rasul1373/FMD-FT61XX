/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: Pro
 * RTE configuration: Pro.rteconfig
*/
#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

/*
 * Define the Device Header File:
*/
#define CMSIS_device_header "ft32f0xx.h"

/* FMD.StdDriverOne::Device.FT32Driver.GPIO */
#define RTE_DEVICE_GPIO
/* FMD.StdDriverOne::Device.FT32Driver.RCC */
#define RTE_DEVICE_RCC
/* FMD.StdDriverOne::Device.Startup */
#define RTE_DEVICE_STARTUP_FT32F0XX    /* Device Startup for FT32F0 */

#endif /* RTE_COMPONENTS_H */
