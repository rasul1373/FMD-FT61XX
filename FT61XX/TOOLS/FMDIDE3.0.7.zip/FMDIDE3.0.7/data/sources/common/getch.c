/*
 * Function: getch
 * Weak implementation.  User implementation may be required
 */

char 
getch(void)
{
	return 0;
}

